# EXACT

*EXcel Applications Comprehension Tool*

![logo](https://github.com/reverse-unina/EXACT/blob/master/EXACTSetup/EXACTGuide/logo.png "logo")

Excel 2010 Addin providing support for comprehension tasks of Excel Applications.

For further information go to the [Wiki](https://github.com/reverse-unina/EXACT/wiki "Wiki")
